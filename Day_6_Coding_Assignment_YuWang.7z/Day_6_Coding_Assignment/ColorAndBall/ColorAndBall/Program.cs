﻿using System;

public class Color
{
    private int red;
    private int green;
    private int blue;
    private int alpha;

    public Color(int red, int green, int blue, int alpha)
    {
        this.red = red;
        this.green = green;
        this.blue = blue;
        this.alpha = alpha;
    }

    public Color(int red, int green, int blue) : this(red, green, blue, 255)
    {
    }

    public int Red
    {
        get { return red; }
        set { red = value; }
    }

    public int Green
    {
        get { return green; }
        set { green = value; }
    }

    public int Blue
    {
        get { return blue; }
        set { blue = value; }
    }

    public int Alpha
    {
        get { return alpha; }
        set { alpha = value; }
    }

    public int GetGrayscale()
    {
        return (red + green + blue) / 3;
    }
}

public class Ball
{
    private int size;
    private Color color;
    private int throwCount;

    public Ball(int size, Color color)
    {
        this.size = size;
        this.color = color;
        this.throwCount = 0;
    }

    public int Size
    {
        get { return size; }
        set { size = value; }
    }

    public Color BallColor
    {
        get { return color; }
        set { color = value; }
    }

    public void Pop()
    {
        size = 0;
    }

    public void Throw()
    {
        if (size > 0)
        {
            throwCount++;
        }
    }

    public int GetThrowCount()
    {
        return throwCount;
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Create some Color instances
        Color redColor = new Color(255, 0, 0);
        Color greenColor = new Color(0, 255, 0);
        Color blueColor = new Color(0, 0, 255, 128); // semi-transparent blue

        // Create some Ball instances
        Ball redBall = new Ball(10, redColor);
        Ball greenBall = new Ball(15, greenColor);
        Ball blueBall = new Ball(20, blueColor);

        // Throw the balls a few times
        redBall.Throw();
        redBall.Throw();
        greenBall.Throw();
        greenBall.Throw();
        greenBall.Throw();
        blueBall.Throw();

        // Pop some balls
        redBall.Pop();
        greenBall.Pop();

        // Try to throw popped balls
        redBall.Throw();
        greenBall.Throw();

        // Print the number of times each ball has been thrown
        Console.WriteLine($"Red ball thrown {redBall.GetThrowCount()} times.");
        Console.WriteLine($"Green ball thrown {greenBall.GetThrowCount()} times.");
        Console.WriteLine($"Blue ball thrown {blueBall.GetThrowCount()} times.");

        // Print grayscale value of colors
        Console.WriteLine($"Red color grayscale: {redColor.GetGrayscale()}");
        Console.WriteLine($"Green color grayscale: {greenColor.GetGrayscale()}");
        Console.WriteLine($"Blue color grayscale: {blueColor.GetGrayscale()}");
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;



public abstract class Person : IPersonService
{
    public string Name { get; private set; }
    public DateTime BirthDate { get; private set; }
    private List<string> addresses = new List<string>();
    protected decimal salary;

    public Person(string name, DateTime birthDate, decimal salary)
    {
        Name = name;
        BirthDate = birthDate;
        this.salary = salary < 0 ? 0 : salary;
    }

    public void AddAddress(string address)
    {
        addresses.Add(address);
    }

    public List<string> GetAddresses()
    {
        return new List<string>(addresses);
    }

    public int CalculateAge()
    {
        return DateTime.Now.Year - BirthDate.Year;
    }

    public abstract decimal CalculateSalary();
}


public class Student : Person, IStudentService
{
    private Dictionary<Course, char> courses = new Dictionary<Course, char>();

    public Student(string name, DateTime birthDate, decimal salary)
        : base(name, birthDate, salary)
    {
    }

    public void EnrollInCourse(Course course)
    {
        if (!courses.ContainsKey(course))
        {
            courses.Add(course, 'F'); // Default grade
            course.EnrollStudent(this);
        }
    }

    public double CalculateGPA()
    {
        if (courses.Count == 0) return 0.0;

        double totalPoints = courses.Sum(c => GradeToPoint(c.Value));
        return totalPoints / courses.Count;
    }

    private double GradeToPoint(char grade)
    {
        return grade switch
        {
            'A' => 4.0,
            'B' => 3.0,
            'C' => 2.0,
            'D' => 1.0,
            'F' => 0.0,
            _ => 0.0,
        };
    }

    public override decimal CalculateSalary()
    {
        return salary; // For students, salary might be a stipend or zero
    }
}


public class Instructor : Person, IInstructorService
{
    public DateTime JoinDate { get; private set; }
    public Department Department { get; private set; }

    public Instructor(string name, DateTime birthDate, decimal salary, DateTime joinDate)
        : base(name, birthDate, salary)
    {
        JoinDate = joinDate;
    }

    public void AssignToDepartment(Department department)
    {
        Department = department;
    }

    public bool IsHeadOfDepartment()
    {
        return Department != null && Department.Head == this;
    }

    public override decimal CalculateSalary()
    {
        int yearsOfExperience = DateTime.Now.Year - JoinDate.Year;
        return salary + (yearsOfExperience * 1000); // Added bonus based on experience
    }
}

public class Course : ICourseService
{
    public string CourseName { get; private set; }
    private Dictionary<Student, char> enrolledStudents = new Dictionary<Student, char>();

    public Course(string courseName)
    {
        CourseName = courseName;
    }

    public void EnrollStudent(Student student)
    {
        if (!enrolledStudents.ContainsKey(student))
        {
            enrolledStudents.Add(student, 'F'); // Default grade
        }
    }

    public void AssignGrade(Student student, char grade)
    {
        if (enrolledStudents.ContainsKey(student))
        {
            enrolledStudents[student] = grade;
        }
    }

    public Dictionary<Student, char> GetEnrolledStudents()
    {
        return new Dictionary<Student, char>(enrolledStudents);
    }
}


public class Department : IDepartmentService
{
    public string DepartmentName { get; private set; }
    public Instructor Head { get; private set; }
    public decimal Budget { get; private set; }
    private List<Course> courses = new List<Course>();

    public Department(string departmentName)
    {
        DepartmentName = departmentName;
    }

    public void SetHead(Instructor instructor)
    {
        Head = instructor;
    }

    public void AddCourse(Course course)
    {
        courses.Add(course);
    }

    public void SetBudget(decimal budget)
    {
        Budget = budget;
    }

    public List<Course> GetCourses()
    {
        return new List<Course>(courses);
    }
}


public interface IPersonService
{
    int CalculateAge();
    decimal CalculateSalary();
    List<string> GetAddresses();
}

public interface IStudentService : IPersonService
{
    void EnrollInCourse(Course course);
    double CalculateGPA();
}

public interface IInstructorService : IPersonService
{
    void AssignToDepartment(Department department);
    bool IsHeadOfDepartment();
}

public interface ICourseService
{
    void EnrollStudent(Student student);
    void AssignGrade(Student student, char grade);
}

public interface IDepartmentService
{
    void SetHead(Instructor instructor);
    void AddCourse(Course course);
    void SetBudget(decimal budget);
}

class Program
{
    static void Main(string[] args)
    {
        // Create an Instructor
        Instructor instructor = new Instructor("John Doe", new DateTime(1980, 1, 1), 50000, new DateTime(2005, 1, 1));
        instructor.AddAddress("123 Main St");

        // Create a Student
        Student student = new Student("Jane Smith", new DateTime(2000, 1, 1), 0);
        student.AddAddress("456 Elm St");

        // Create a Course
        Course course = new Course("Computer Science 101");
        student.EnrollInCourse(course);
        course.AssignGrade(student, 'A');

        // Create a Department
        Department department = new Department("Computer Science");
        department.SetHead(instructor);
        department.AddCourse(course);
        department.SetBudget(1000000);

        // Output Instructor Info
        Console.WriteLine($"Instructor: {instructor.Name}, Age: {instructor.CalculateAge()}, Salary: {instructor.CalculateSalary()}, Is Head: {instructor.IsHeadOfDepartment()}");

        // Output Student Info
        Console.WriteLine($"Student: {student.Name}, Age: {student.CalculateAge()}, GPA: {student.CalculateGPA()}");

        // Output Department Info
        Console.WriteLine($"Department: {department.DepartmentName}, Head: {department.Head.Name}, Budget: {department.Budget}");
    }
}
